create view chat_history_view(id, user_id, username, role_type, sender, message, timestamp) as
SELECT h.id,
       h.user_id,
       u.username,
       h.role_type,
       h.sender,
       h.message,
       h."timestamp"
FROM chat_history h
         JOIN users u ON h.user_id = u.id::text;

alter table chat_history_view
    owner to echosoul;

